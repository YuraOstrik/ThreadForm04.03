import { createContext } from "react";

const AppContext = createContext({
  request: async () => {},
  backUrl: "",
  user: null,
  setToken: () => {}
});

export default AppContext;
