import './App.css';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useEffect, useState, Suspense } from 'react';

import { Home } from './Pages/Home';
import { Network } from './Pages/Network';
import { Vacancies } from './Pages/Vacancies';
import { Messages } from './Pages/Messages';
import { Notification } from './Pages/Notification';
import { MyProfilePortfolio } from './Pages/MyProfilePortfolio';

import { Registration } from './Modals/Registration';
import { Verification } from './Modals/Verification';
import { Entrance } from './Modals/Entrance';
import { EntranceVerification } from './Modals/EntranceVerification';

import { MainPages } from './MainPages';
import { LandingPage } from './LandingPage';

import AppContext from './AppContext';
import './i18n';
import Base64 from './Base64';

function App() {
  const [token, setToken] = useState(null);
  const [user, setUser] = useState(null);

  const tokenKey = "asp-p32-token";
  const backUrl = "https://localhost:7294";
  
  const handleSetToken = (newTokenData) => {
    let tokenString = null;
    
    // 1. Проверяем, если передали объект с полем 'token' (ответ сервера)
    if (typeof newTokenData === 'object' && newTokenData !== null && newTokenData.token && typeof newTokenData.token === 'string') {
        tokenString = newTokenData.token;
        console.log("Defensive fix: Extracted token string from object.");
    } 
    else if (typeof newTokenData === 'string' || newTokenData === null) {
        tokenString = newTokenData;
    } 
    
    setToken(tokenString);
  };

  useEffect(() => {
    const savedToken = localStorage.getItem(tokenKey);
    
    if (savedToken) {
      setToken(savedToken);
    }
  }, [tokenKey]);

  useEffect(() => {
    const jwt = token;

    if (!jwt) {
      setUser(null);
      localStorage.removeItem(tokenKey);
      return;
    }

    try {
      if (typeof jwt !== 'string' || !jwt.includes('.')) {
        console.error("Token state is not a valid JWT string, clearing token.");
        setUser(null);
        localStorage.removeItem(tokenKey);
        return;
      }

      const decoded = Base64.jwtDecodePayload(jwt);
      console.log("Decoded JWT:", decoded);

      setUser(decoded);

      localStorage.setItem(tokenKey, jwt); 
    } catch (err) {
      console.error("JWT decode error, clearing token:", err);
      setUser(null);
      localStorage.removeItem(tokenKey);
    }
  }, [token, tokenKey]);

  const request = (url, conf) => new Promise((resolve, reject) => {
    localStorage.removeItem("token");
  if (url.startsWith('/')) {
      url = backUrl + url;

      if (token) {
        conf = conf || {};
        conf.headers = conf.headers || {};
        if (!conf.headers['Authorization']) {
          conf.headers['Authorization'] = 'Bearer ' + token;
        }
      }
    }

    fetch(url, conf)
      .then(r => r.json())
      .then(j => {
        if (j.status?.isOk || j.token) {
          resolve(j.data ?? j);
        } else {
          reject(j);
        }
      })
      .catch(err => reject({ message: 'Network error', error: err }));
  });


  return (

    <AppContext.Provider value={{ request, backUrl, user, setToken: handleSetToken }}>
        <Router>
            <Routes>
                <Route path="/landingPage" element={<LandingPage />} />
                <Route path="/entrance" element={<Entrance />} />
                <Route path="/registration" element={<Registration />} />
                <Route path="/verification" element={<Verification />} />
                <Route path="/entranceVerification" element={<EntranceVerification />} />


                <Route
                    path="/*"
                    element={
                        user ? (
                            <MainPages />
                        ) : (
                            <Navigate to="/landingPage" replace />
                        )
                    }
                >
                    <Route index element={<Home />} />
                    <Route path="home" element={<Home />} />
                    <Route path="network" element={<Network />} />
                    <Route path="vacancies" element={<Vacancies />} />
                    <Route path="messages" element={<Messages />} />
                    <Route path="notification" element={<Notification />} />
                    <Route path="myProfilePortfolio" element={<MyProfilePortfolio />} />
                </Route>
            </Routes>
        </Router>
    </AppContext.Provider>

  );
}

export default App;

